<p align="center"><a href="https://xnodde.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Xnodde Logo"></a></p>



## About OneMarket

One market is an api for one market Apps. One market is an african market management and bills management system. this APi was built for the standalone pc app, the users mobile app and the task force mobile app.
its features include.

- bill payment system.
- Inventory for Shop Owners.
- Market management with user record management.
- and more


## Security Vulnerabilities

If you discover a security vulnerability within One Market, please send an e-mail to Taylor Otwell via [admin@xnodde.com](mailto:admin@xnodde.com). All security vulnerabilities will be promptly addressed.

## License

The One market API is licensed under the [MIT license](https://opensource.org/licenses/MIT).
