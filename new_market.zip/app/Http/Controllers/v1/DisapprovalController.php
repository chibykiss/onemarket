<?php

namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use App\Models\Apprentice;
use App\Models\Attachee;
use App\Models\Owner;
use App\Models\Shop;
use App\Models\Taskforce;
use App\Models\User;
use App\Models\Worker;
use App\Traits\HttpResponses;
use Illuminate\Http\Request;

class DisapprovalController extends Controller
{
    use HttpResponses;

    public function disapproveUser(User $member)
    {
        return $this->disapprove($member, "User");
    }
    public function disapproveShop(Shop $shop)
    {
        return $this->disapprove($shop, "Shop");
    }

    public function disapproveOwner(Owner $owner)
    {
        return $this->disapprove($owner, "Owner");
    }

    public function disapproveAttachee(Attachee $attachee)
    {
        return $this->disapprove($attachee, "Attachee");
    }
    public function disapproveApprentice(Apprentice $apprentice)
    {
        return $this->disapprove($apprentice, "Apprentice");
    }

    public function disapproveWorker(Worker $worker)
    {
        return $this->disapprove($worker, "Worker");
    }

    public function disapproveTaskforce(Taskforce $taskforce)
    {
        return $this->disapprove($taskforce, "Taskforce");
    }

    private function disapprove($who, string $message)
    {
        //return 10;
        $who->update([
            'approved' => "0",
        ]);
        return $this->success([
            'status' => 'success',
            'message' => "$message has been disapproved"
        ]);
    }
}
