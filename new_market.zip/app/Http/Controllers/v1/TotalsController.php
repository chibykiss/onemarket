<?php

namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use App\Models\Apprentice;
use App\Models\Attachee;
use App\Models\User;
use App\Models\Worker;
use GrahamCampbell\ResultType\Success;
use Illuminate\Http\Request;

class TotalsController extends Controller
{
    public function totalMembers(){
        $users = User::all()->count();
        return response()->json([
            'status' => 'success',
            'data' => [
                'total' => $users,
            ],
        ]);
    }

    public function totalAttachees(){
        $attachees = Attachee::all()->count();
        return response()->json([
            'status' => 'success',
            'data' => [
                'total' => $attachees,
            ],
        ]);
    }

    public function totalApprentices(){
        $apprentices = Apprentice::all()->count();
        return response()->json([
            'status' => 'success',
            'data' => [
                'total' => $apprentices,
            ],
        ]);
    }

    public function totalWorkers(){
        $workers = Worker::all()->count();
        return response()->json([
            'status' => 'success',
            'data' => [
                'total' => $workers,
            ],
        ]);
    }

}
